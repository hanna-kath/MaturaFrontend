export class ContactPoint {
  constructor(
    public value: string = '',
    public text: string = ''
  ) {
  }
}
