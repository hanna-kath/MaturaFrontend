export class Identifier {
  constructor(
    public value: string = '',
    public use: string = '',
    public system: string = ''
  ) {
  }
}
