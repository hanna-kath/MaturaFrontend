export class HumanName {
  constructor(
    public id: string = '',
    public use: string = '',
    public text: string = '',
    public family: string = '',
    public given: string = '',
    public prefix: string = '',
    public suffix: string = ''
  ) {
  }
}
